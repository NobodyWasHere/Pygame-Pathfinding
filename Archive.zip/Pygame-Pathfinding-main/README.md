# Pygame-Pathfinding
A pathfinding algorithm I made with Pygame.

# Use
pygame must be installed (if not, look at https://www.pygame.org/wiki/GettingStarted)  
Open pathfindpg.py with python

# Controls
left click : Set new position for start/end  
middle click : toggle between start and end  
right click : draw/erase wall  
left shift : remove all  
left ctrl : remove path  
space : run pathfind algorithm  
